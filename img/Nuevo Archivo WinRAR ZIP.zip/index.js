var path = document.querySelector('path.nike');
var length = path.getTotalLength();
console.log(length)

